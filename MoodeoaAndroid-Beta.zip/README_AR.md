# Moodeoa Smart — Android Beta

نسخة Android تجريبية من Moodeoa.

ملاحظة: هذه النسخة الحالية تفتح نسخة Moodeoa المنشورة داخل WebView.
قفل Android الحقيقي (منع الانتقال لتطبيقات أخرى) يحتاج مرحلة Native لاحقة.

للبناء:
- افتح المشروع في Android Studio
- Build > Build APK(s)
- أو: ./gradlew assembleDebug

APK:
app/build/outputs/apk/debug/app-debug.apk
